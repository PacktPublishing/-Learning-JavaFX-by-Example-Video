package loginpage;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.VBox;
import javafx.scene.text.Text;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.stage.Window;

/**
 *
 * @author Smail
 */
public class FXMLDocumentController implements Initializable {
    
    @FXML
    private TextField usernameTextField;
    @FXML
    private TextField passwordTextField;
    @FXML
    private Button button;
    @FXML
    private Text resultText;
    
    @FXML
    private void handleButtonAction(ActionEvent event) {
        String username = usernameTextField.getText();
        String password = passwordTextField.getText(); 
        
        
                
                
        if("javafx".equals(username) && "letmepass".equals(password)){
            resultText.setText("You shall pass !");
        }else{
            resultText.setText("You shall NOT pass !");
        }
    }
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    
}
