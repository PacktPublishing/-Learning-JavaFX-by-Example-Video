package todo;

import java.net.URL;
import java.time.LocalDate;
import java.util.ResourceBundle;
import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.paint.Color;

/**
 *
 * @author Smail
 */
public class TodoController implements Initializable {
    
    @FXML
    private Label notificationLabel;
       
    @FXML
    private TextField titleTextField;
    
    @FXML
    private TextArea descriptionTextArea;
    
    @FXML
    private TableView table;
    
    @FXML
    private TableColumn titleColumn, descriptionColumn, dateColumn, statusColumn, priorityColumn;
    
    @FXML
    private ComboBox priorityComboBox, statusComboBox;
    
    @FXML
    private DatePicker datePicker;
    
    ObservableList<Task> tasks;
    
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        
        /// Initializing the tasks list
        tasks = FXCollections.observableArrayList();
        
        /// Initializing the Priority combobox
        priorityComboBox.setItems( FXCollections.observableArrayList("Urgent", "High", "Medium", "Low"));
        priorityComboBox.getSelectionModel().select(0);
        
        /// Initializing the status combobox
        statusComboBox.setItems( FXCollections.observableArrayList("New", "In-Progress", "Done"));
        statusComboBox.getSelectionModel().select(0);
        
        /// Initializing the date picker
        datePicker.setValue(LocalDate.now());
        
        titleColumn.setCellValueFactory(new PropertyValueFactory("title"));
        descriptionColumn.setCellValueFactory(new PropertyValueFactory("description"));
        dateColumn.setCellValueFactory(new PropertyValueFactory("date"));
        priorityColumn.setCellValueFactory(new PropertyValueFactory("priority"));
        statusColumn.setCellValueFactory(new PropertyValueFactory("status"));
                
        table.setItems(tasks);
    }   
    
    public void handleSaveAction(){
    
        if(!titleTextField.getText().isEmpty()){
        
            Task t = new Task();
            
            t.setTitle(titleTextField.getText());
       
            if(!descriptionTextArea.getText().isEmpty()) 
                t.setDescription(descriptionTextArea.getText());
            
            t.setDate(datePicker.getValue().toString());
            t.setPriority(priorityComboBox.getSelectionModel().getSelectedItem().toString());
            t.setStatus(statusComboBox.getSelectionModel().getSelectedItem().toString());

            tasks.add(t); 
        }else{
           notificationLabel.setTextFill(Color.RED);
           notificationLabel.setText("The Title is required");
        }
    }
    
    public void handleResetAction(){
        titleTextField.clear();
        descriptionTextArea.clear();
        statusComboBox.getSelectionModel().select(-1);
        priorityComboBox.getSelectionModel().select(-1);
        datePicker.setValue(null);
    }
    
    public void handleCloseAction(){
        Platform.exit();
    } 
}
