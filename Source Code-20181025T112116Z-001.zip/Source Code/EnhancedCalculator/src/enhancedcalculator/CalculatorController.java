/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package enhancedcalculator;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;

/**
 *
 * @author Smail
 */
public class CalculatorController implements Initializable {
    
    Float data = 0f;
    int operation = -1;
    
    @FXML
    public TextField textField;
    
    @FXML
    public Button one, two, three, four, five, six, seven, eight, nine, ten,
                  zero, plus, minus, division, multiplication, clear, comma, equals;
    
      @FXML
    void handleButtonAction(ActionEvent event) {
        if (event.getSource() == one) {
            textField.setText(textField.getText() + "1");
        } else if (event.getSource() == two) {
            textField.setText(textField.getText() + "2");
        } else if (event.getSource() == three) {
            textField.setText(textField.getText() + "3");
        } else if (event.getSource() == four) {
            textField.setText(textField.getText() + "4");
        } else if (event.getSource() == five) {
            textField.setText(textField.getText() + "5");
        } else if (event.getSource() == six) {
            textField.setText(textField.getText() + "6");
        } else if (event.getSource() == seven) {
            textField.setText(textField.getText() + "7");
        } else if (event.getSource() == eight) {
            textField.setText(textField.getText() + "8");
        } else if (event.getSource() == nine) {
            textField.setText(textField.getText() + "9");
        } else if (event.getSource() == zero) {
            textField.setText(textField.getText() + "0");
        } else if (event.getSource() == clear) {
            textField.setText("");
        }
    }
    
    
      @FXML
    void handleOperation(ActionEvent event) {
        if (event.getSource() == plus) {
            data = Float.parseFloat(textField.getText());
            operation = 1; //Addition
            textField.setText("");
        } else if (event.getSource() == minus) {
            data = Float.parseFloat(textField.getText());
            operation = 2; //Substraction
            textField.setText("");
        } else if (event.getSource() == multiplication) {
            data = Float.parseFloat(textField.getText());
            operation = 3; //Mul
            textField.setText("");
        } else if (event.getSource() == division) {
            data = Float.parseFloat(textField.getText());
            operation = 4; //Division
            textField.setText("");
        } else if (event.getSource() == equals) {
            Float secondOperand = Float.parseFloat(textField.getText());
            switch (operation) {
                case 1: //Addition
                    Float ans = data + secondOperand;
                    textField.setText(String.valueOf(ans));break;
                case 2: //Subtraction
                    ans = data - secondOperand;
                    textField.setText(String.valueOf(ans));break;
                case 3: //Mul
                    ans = data * secondOperand;
                    textField.setText(String.valueOf(ans));break;
                case 4: //Div
                    ans = 0f;
                    try {
                        ans = data / secondOperand;
                    }catch(Exception e){textField.setText("Error");}
                    textField.setText(String.valueOf(ans));break;
            }
        }
    }
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        
        //Making the Text Field non editable
        textField.setEditable(false);
    }   
}
