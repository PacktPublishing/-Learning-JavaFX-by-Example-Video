/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package calculator;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.text.Text;

/**
 *
 * @author Smail
 */
public class FXMLDocumentController implements Initializable {
    
    @FXML
    private Text resultText;
    @FXML
    private Button additionButton;
    @FXML
    private Button mutiplicationButton;
    @FXML
    private TextField firstNumber;
    @FXML
    private TextField secondNumber;
     
    @FXML
    private void additionButtonClicked(ActionEvent event){
        
        // Getting the values from the text fields
        String first = firstNumber.getText();
        String second = secondNumber.getText();
        
        // Converting to int
        double firstNum = Double.parseDouble(first.trim());
        double secondNum = Double.parseDouble(first.trim());
        
        double resultNumber = firstNum + secondNum;
        resultText.setText(String.valueOf(resultNumber));
    }
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    
    
}
